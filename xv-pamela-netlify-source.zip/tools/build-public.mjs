import fs from "node:fs/promises";
import path from "node:path";

const publicDir = "public";
const publicAssetsDir = path.join(publicDir, "assets");
const assetAllowList = [
  "flores.png",
  "fondo-inicial3.png",
  "fortin-plaza.jpg",
  "foto1.jpeg",
  "foto2.jpg",
  "foto3.jpg",
  "foto4.jpg",
  "iglesia-jalatlaco.jpg",
  "one-last-time.mp3"
];

await fs.rm(publicDir, { recursive: true, force: true });
await fs.mkdir(publicAssetsDir, { recursive: true });
await fs.copyFile("index.html", path.join(publicDir, "index.html"));
await fs.copyFile("validar-pase.html", path.join(publicDir, "validar-pase.html"));
await fs.copyFile("LIST_INV_XV_PAME_con_folios.xlsx", path.join(publicDir, "LIST_INV_XV_PAME_con_folios.xlsx"));

for (const asset of assetAllowList) {
  await fs.copyFile(path.join("assets", asset), path.join(publicAssetsDir, asset));
}

console.log(`Built ${publicDir}`);

import fs from "node:fs";

const guests = JSON.parse(fs.readFileSync(new URL("./guests.json", import.meta.url), "utf8"));
const PASSWORD = "P4m3l4XVs";

function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    },
    body: JSON.stringify(body)
  };
}

export async function handler(event) {
  if (event.httpMethod !== "POST") {
    return json(405, { ok: false, message: "Método no permitido." });
  }

  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch (error) {
    return json(400, { ok: false, message: "Solicitud inválida." });
  }

  if (String(body.password || "") !== PASSWORD) {
    return json(401, { ok: false, message: "Contraseña incorrecta." });
  }

  const folio = String(body.folio || "").trim().toUpperCase();
  const guest = guests.find((item) => item.folio === folio);
  if (!guest) {
    return json(404, { ok: false, message: "Este folio no aparece en la lista de invitados." });
  }

  return json(200, {
    ok: true,
    guest: {
      name: guest.name,
      companions: Number(guest.companions) || 0,
      folio: guest.folio,
      totalAccess: (Number(guest.companions) || 0) + 1
    }
  });
}

import { getStore } from "@netlify/blobs";
import fs from "node:fs";

const guests = JSON.parse(fs.readFileSync(new URL("./guests.json", import.meta.url), "utf8"));

function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    },
    body: JSON.stringify(body)
  };
}

function publicGuest(guest, status) {
  return {
    name: guest.name,
    companions: Number(guest.companions) || 0,
    folio: guest.folio,
    openedAt: status.openedAt || null,
    confirmedAt: status.confirmedAt || null,
    alreadyConfirmed: Boolean(status.confirmedAt)
  };
}

export async function handler(event) {
  if (event.httpMethod !== "POST") {
    return json(405, { ok: false, message: "Método no permitido." });
  }

  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch (error) {
    return json(400, { ok: false, message: "Solicitud inválida." });
  }

  const folio = String(body.folio || "");
  const token = String(body.clave || "");
  const guest = guests.find((item) => item.folio === folio && item.token === token);

  if (!guest) {
    return json(403, {
      ok: false,
      message: "Este link no corresponde a un pase válido."
    });
  }

  const store = getStore("pamela-invite-status");
  const current = await store.get(folio, { type: "json" });
  const status = current || {
    folio,
    openedAt: new Date().toISOString(),
    confirmedAt: null
  };

  if (!status.confirmedAt) {
    status.confirmedAt = new Date().toISOString();
    await store.setJSON(folio, status);
  }

  return json(200, {
    ok: true,
    guest: publicGuest(guest, status)
  });
}

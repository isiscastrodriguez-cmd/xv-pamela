import guests from "./guests.json" with { type: "json" };


function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    },
    body: JSON.stringify(body)
  };
}

function normalize(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toUpperCase();
}

function firstParts(name) {
  const parts = normalize(name).split(" ").filter(Boolean);
  return {
    firstName: parts[0] || "",
    firstLastName: parts[1] || ""
  };
}

function publicGuest(guest) {
  return {
    name: guest.name,
    companions: Number(guest.companions) || 0,
    folio: guest.folio,
    confirmedAt: null,
    openedAt: null
  };
}

export async function handler(event) {
  if (event.httpMethod !== "POST") {
    return json(405, { ok: false, message: "Método no permitido." });
  }

  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch (error) {
    return json(400, { ok: false, message: "Solicitud inválida." });
  }

  const fullName = normalize(body.fullName);
  const firstName = normalize(body.firstName);
  const firstLastName = normalize(body.firstLastName);
  if (!fullName && (!firstName || !firstLastName)) {
    return json(400, { ok: false, message: "Ingresa tu nombre completo." });
  }

  const matches = guests.filter((guest) => {
    if (fullName) return normalize(guest.name) === fullName;
    const parts = firstParts(guest.name);
    return parts.firstName === firstName && parts.firstLastName === firstLastName;
  });

  if (!matches.length) {
    return json(404, { ok: false, message: "No encontramos un invitado con esos datos. Revisa acentos o espacios e intenta de nuevo." });
  }

  if (matches.length > 1) {
    return json(409, { ok: false, message: "Hay más de un invitado con esos datos. Solicita tu link personalizado para consultar el pase exacto." });
  }

  return json(200, { ok: true, guest: publicGuest(matches[0]) });
}
